'use strict';

// by the time this script has finished loading, the document would be loaded, so we can just run our code as normal.
{
	console.log( "hello world from console (extension)" );
}
